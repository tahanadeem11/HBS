const headerHTML = `
<!-- Start Argo Mobile Header -->
<header class="argo-mobile-header">
    <div class="mobile-logo-bar">
        <div class="mobile-logo">
            <a href="index.html"><img src="assets/images/Home By Soni Updated (2).png" alt="Home By Sohny Logo"></a>
        </div>
    </div>
    <div class="mobile-nav-bar">
        <div class="mobile-nav-container">
            <button class="mobile-nav-toggler" type="button">
                <span class="fa fa-bars"></span>
            </button>
            <a href="tel:9255239723" class="mobile-cta">GET A FREE QUOTE</a>
        </div>
    </div>
</header>
<!-- End Argo Mobile Header -->

<!-- Mobile Menu Sidebar -->
<div class="mobile-menu-sidebar">
    <div class="menu-backdrop"></div>
    <div class="menu-box">
        <div class="close-btn"><span class="fa fa-times"></span></div>
        <div class="nav-logo">
            <a href="index.html"><img src="assets/images/Home By Soni Updated (2).png" alt="Logo"></a>
        </div>
        <nav class="menu-outer">
            <ul class="navigation">
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li class="dropdown">
                    <a href="#">Area</a>
                    <ul>
                        <li><a href="verona.html">Verona, CA</a></li>
                        <li><a href="dublin.html">Dublin, CA</a></li>
                        <li><a href="san-ramon.html">San Ramon, CA</a></li>
                        <li><a href="sunol.html">Sunol, CA</a></li>
                        <li><a href="scotts-corner.html">Scotts Corner, Sunol, CA</a></li>
                        <li><a href="kimber-gomes.html">Kimber-Gomes, Fremont, CA</a></li>
                        <li><a href="norris-canyon.html">Norris Canyon, CA</a></li>
                        <li><a href="hayward-highland.html">Hayward Highland, Hayward, CA</a></li>
                        <li><a href="livermore.html">Livermore, CA</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="services.html">Services</a>
                    <ul>
                        <li><a href="services.html">View All Services</a></li>
                        <li><a href="ser-vacant-home-staging.html">Vacant Home Staging</a></li>
                        <li><a href="ser-occupied-home-staging.html">Occupied Home Staging</a></li>
                        <li><a href="ser-partial-home-staging.html">Partial Home Staging</a></li>
                        <li><a href="ser-full-home-staging.html">Full Home Staging</a></li>
                        <li><a href="ser-home-staging-consultation.html">Home Staging Consultation</a></li>
                    </ul>
                </li>
                <li><a href="gallery.html">Gallery</a></li>
                <li><a href="faq.html">FAQs</a></li>
                <li><a href="contact.html">Contact Us</a></li>
            </ul>
        </nav>
        <div class="contact-info">
            <h4>Contact Info</h4>
            <ul>
                <li><span class="fa fa-phone"></span> <a href="tel:+19255239723">(925)-523-9723</a></li>
                <li><span class="fa fa-envelope"></span> <a href="mailto:sohny@homebysohny.com">sohny@homebysohny.com</a></li>
            </ul>
        </div>
    </div>
</div>
<!-- End Mobile Menu Sidebar -->

<!-- Start Argo Header -->
<header class="argo-main-header">
    <!-- TOP BAR -->
    <div class="argo-top-bar">
        <div class="argo-container">
            <div class="argo-top-inner">
                <div class="argo-top-left">
                    Mon–Sun : 7:30 AM – 9:00 PM
                </div>
                <div class="argo-top-right">
                    <ul class="argo-social-links">
                        <li><a href="https://www.facebook.com/people/Home-By-Sohny-LLC/61585006493260/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://www.pinterest.com/homebysohnyllc/" target="_blank"><i class="fa fa-pinterest"></i></a></li>
                        <li><a href="https://g.page/r/CTvPuSXI_XYcEBM/" target="_blank"><i class="fa fa-google"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- INFO BAR -->
    <div class="argo-info-bar">
        <div class="argo-info-container">
            <div class="argo-logo">
                <a href="index.html"><img src="assets/images/Home By Soni Updated (2).png" alt="Home By Sohny Logo"></a>
            </div>
            <div class="argo-info-items">
                <div class="argo-info-item">
                    <div class="argo-info-icon"><span class="flaticon-pin-1"></span></div>
                    <div>
                        <strong>We Serve</strong>
                        <span>Pleasantone Area</span>
                    </div>
                </div>
                <div class="argo-info-item">
                    <div class="argo-info-icon"><span class="flaticon-telephone"></span></div>
                    <div>
                        <strong>Office Number</strong>
                        <span><a href="tel:+19255239723">925-523-9723</a></span>
                    </div>
                </div>
                <div class="argo-info-item">
                    <div class="argo-info-icon"><span class="flaticon-email"></span></div>
                    <div>
                        <strong>Send Your Mail</strong>
                        <span><a href="mailto:sohny@homebysohny.com">sohny@homebysohny.com</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- NAV BAR -->
    <div class="argo-nav-bar">
        <div class="argo-nav-container">
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li class="argo-dropdown">
                        <a href="#">Area</a>
                        <ul>
                            <li><a href="verona.html">Verona, CA</a></li>
                            <li><a href="dublin.html">Dublin, CA</a></li>
                            <li><a href="san-ramon.html">San Ramon, CA</a></li>
                            <li><a href="sunol.html">Sunol, CA</a></li>
                            <li><a href="scotts-corner.html">Scotts Corner, Sunol, CA</a></li>
                            <li><a href="kimber-gomes.html">Kimber-Gomes, Fremont, CA</a></li>
                            <li><a href="norris-canyon.html">Norris Canyon, CA</a></li>
                            <li><a href="hayward-highland.html">Hayward Highland, Hayward, CA</a></li>
                            <li><a href="livermore.html">Livermore, CA</a></li>
                        </ul>
                    </li>
                    <li class="argo-dropdown">
                        <a href="services.html">Services</a>
                        <ul>
                            <li><a href="services.html">View All Services</a></li>
                            <li><a href="ser-vacant-home-staging.html">Vacant Home Staging</a></li>
                            <li><a href="ser-occupied-home-staging.html">Occupied Home Staging</a></li>
                            <li><a href="ser-partial-home-staging.html">Partial Home Staging</a></li>
                            <li><a href="ser-full-home-staging.html">Full Home Staging</a></li>
                            <li><a href="ser-home-staging-consultation.html">Home Staging Consultation</a></li>
                        </ul>
                    </li>
                    <li><a href="gallery.html">Gallery</a></li>
                    <li><a href="faq.html">FAQs</a></li>
                    <li><a href="contact.html">Contact Us</a></li>
                </ul>
            </nav>
            <a href="tel:9255239723" class="argo-cta">Get a free quote</a>
        </div>
    </div>
</header>
<!-- End Argo Header -->
`;

